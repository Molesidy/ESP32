import machine
import uos
import gc
import time

def print_system_info():
    """打印ESP32S3的系统信息"""
    
    # Flash信息
    fs_stat = uos.statvfs('/')
    total_flash = fs_stat[0] * fs_stat[2]
    free_flash = fs_stat[0] * fs_stat[3]
    
    # SRAM信息
    allocated_ram = gc.mem_alloc() #已申请的内存
    free_ram = gc.mem_free() #剩余内存
    total_ram = allocated_ram + free_ram
    
    # 时钟频率
    cpu_freq = machine.freq()
    
    # 打印信息
    print("=" * 30)
    print("ESP32S3 系统信息")
    print("=" * 30)
    print(f"Flash: 总空间 {total_flash / 1024:.2f} KB, 可用 {free_flash / 1024:.2f} KB")
    print(f"SRAM: 总空间 {total_ram / 1024:.2f} KB, 已用 {allocated_ram / 1024:.2f} KB, 空闲 {free_ram / 1024:.2f} KB")
    print(f"CPU: 时钟频率 {cpu_freq / 1000000:.2f} MHz")
    print("=" * 30)

def led1_toggle():
    """控制LED闪烁"""
    led1.value(1)         # 点亮LED
    time.sleep_ms(100)    # 延时100毫秒
    led1.value(0)         # 熄灭LED
    time.sleep_ms(100)    # 延时100毫秒

def main():
    """主函数，程序的入口点"""
    global led1  # 声明led1为全局变量，以便在其他函数中使用
    
    # 初始化硬件
    led1 = machine.Pin(1, machine.Pin.OUT)
    
    # 打印系统信息
    print_system_info()
    
    # 主循环
    try:
        while True:
            led1_toggle()
    except KeyboardInterrupt:
        print("\n程序已停止")
        led1.value(0)  # 确保LED在程序退出时熄灭

# 程序入口点
if __name__ == '__main__':
    main()