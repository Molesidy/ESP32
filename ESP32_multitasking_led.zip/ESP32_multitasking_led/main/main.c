#include "sdkconfig.h"
#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
//#include "esp_spi_flash.h"//已废弃
#include "spi_flash_mmap.h"

#include "bsp_led.h"

//led1
uint32_t led1_task_stack_size_word = 1024*3;//栈深度，单位：字节
UBaseType_t uxPriority_led1 = 2;//优先级
TaskHandle_t xHandle_led1;//任务句柄

//led2
uint32_t led2_task_stack_size_word = 1024*3;//栈深度，单位：字节
UBaseType_t uxPriority_led2 = 2;//优先级
TaskHandle_t xHandle_led2;//任务句柄

//led3
#define led3_task_stack_size_word 1024*3//栈深度，单位: 字节
UBaseType_t uxPriority_led3 = 2;//优先级
StackType_t puxStackBuffer_led3[led3_task_stack_size_word];//静态分配的栈
StaticTask_t xHandle_led3;//任务句柄

void led1_task(void *pvParameters)
{
    
    while (1) {
        printf("LED1 Task is running\n");
        bsp_led1_toggle();
    }
}

void led2_task(void *pvParameters)
{
    
    while (1) {
        printf("LED2 Task is running\n");
        bsp_led2_toggle();
    }
}

void led3_task(void *pvParameters)
{
    
    while (1) {
        printf("LED3 Task is running\n");
        bsp_led3_toggle();
    }
}

void app_main(void)
{
    // 初始化LED硬件
    bsp_led_init();

    // 动态创建LED1任务
    xTaskCreate(led1_task,       // 任务函数指针（入口函数）
                "led1_task",       // 任务名称（用于调试，长度建议不超过 configMAX_TASK_NAME_LEN）
                led1_task_stack_size_word,     // 任务栈大小（单位：字节）
                NULL,       // 传递给任务函数的参数（可空）
                uxPriority_led1,          // 任务优先级（0 为最低，configMAX_PRIORITIES-1 为最高）
                &xHandle_led1  // 任务句柄（用于后续操作任务，如删除、挂起等）（可空）
                );
    
    // 动态创建LED2任务
    xTaskCreate(led2_task,       // 任务函数指针（入口函数）
                "led2_task",       // 任务名称（用于调试，长度建议不超过 configMAX_TASK_NAME_LEN）
                led2_task_stack_size_word,     // 任务栈大小（单位：字节）
                NULL,       // 传递给任务函数的参数（可空）
                uxPriority_led2,          // 任务优先级（0 为最低，configMAX_PRIORITIES-1 为最高）
                &xHandle_led2  // 任务句柄（用于后续操作任务，如删除、挂起等）（可空）
                );

    // 静态创建LED3任务
    xTaskCreateStatic(led3_task,       // 任务函数指针（入口函数）
                        "led3_task",       // 任务名称（用于调试，长度建议不超过 configMAX_TASK_NAME_LEN）
                        led3_task_stack_size_word,     // 任务栈大小（单位：字节）
                        NULL,       // 传递给任务函数的参数（可空）
                        uxPriority_led3,          // 任务优先级（0 为最低，configMAX_PRIORITIES-1 为最高）
                        puxStackBuffer_led3,  // 任务句柄（用于后续操作任务，如删除、挂起等）（可空）
                        &xHandle_led3); // 静态分配的任务控制块

    // vTaskStartScheduler();//ESP-IDF v5.0 及以上版本不需要调用此函数，FreeRTOS 已经在底层自动启动调度器  
 	// for( ;; );//ESP-IDF v5.0 及以上版本不需要调用此函数，FreeRTOS 已经在底层自动启动调度器 
}
