#ifndef BSP_LED_H
#define BSP_LED_H

#define LED1_GPIO_PIN GPIO_NUM_1

#define LED2_GPIO_PIN GPIO_NUM_2

#define LED3_GPIO_PIN GPIO_NUM_3

void bsp_led_init(void);
void bsp_led1_toggle(void);
void bsp_led2_toggle(void);
void bsp_led3_toggle(void);

#endif // BSP_LED_H
