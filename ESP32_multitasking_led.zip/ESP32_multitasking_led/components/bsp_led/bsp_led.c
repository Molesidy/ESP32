#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "bsp_led.h"

#include "driver/gpio.h"

void bsp_led_init(void)
{
    //初始化LED1
    gpio_config_t io_conf = {
       .pin_bit_mask = (1ULL << LED1_GPIO_PIN),
       .mode = GPIO_MODE_OUTPUT,
       .pull_up_en = GPIO_PULLUP_ENABLE,
       .pull_down_en = GPIO_PULLDOWN_DISABLE,
       .intr_type = GPIO_INTR_DISABLE  
    };
    gpio_config(&io_conf);
    //gpio_set_direction(LED1_GPIO_PIN, GPIO_MODE_OUTPUT);
    //gpio_set_level(LED1_GPIO_PIN, 1); // 默认关闭LED1

    //初始化LED2
    
    gpio_set_direction(LED2_GPIO_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(LED2_GPIO_PIN, 1); // 默认关闭LED2

    //初始化LED3
    gpio_set_direction(LED3_GPIO_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(LED3_GPIO_PIN, 1); // 默认关闭LED3
}

void bsp_led1_toggle(void)
{
    // gpio_set_level(LED1_GPIO_PIN, !gpio_get_level(LED1_GPIO_PIN));//无作用
    // vTaskDelay(pdMS_TO_TICKS(100));//CONFIG_FREERTOS_HZ//无作用

    gpio_set_level(LED1_GPIO_PIN, 1);
    vTaskDelay(1000);
    gpio_set_level(LED1_GPIO_PIN, 0);
    vTaskDelay(1000);
}

void bsp_led2_toggle(void)
{
    gpio_set_level(LED2_GPIO_PIN, 1);
    vTaskDelay(2000);
    gpio_set_level(LED2_GPIO_PIN, 0);
    vTaskDelay(2000);
}

void bsp_led3_toggle(void)
{
    gpio_set_level(LED3_GPIO_PIN, 1);
    vTaskDelay(3000);
    gpio_set_level(LED3_GPIO_PIN, 0);
    vTaskDelay(3000);
}